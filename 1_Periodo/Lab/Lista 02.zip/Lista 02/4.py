#4- Faça um programa, utilizando while, que mostre na tela os números de 0 a 100.

x = 0
print (x)

while x != 100:
    x = x + 1
    print (x)