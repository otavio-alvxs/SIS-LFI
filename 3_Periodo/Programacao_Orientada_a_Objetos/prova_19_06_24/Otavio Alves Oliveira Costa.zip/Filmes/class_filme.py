class filme:
    def __init__(self, titulo, ano, genero, runtime, diretor) -> None:
        self.titulo = titulo
        self.ano = ano
        self.genero = genero
        self.runtime = runtime
        self.diretor = diretor