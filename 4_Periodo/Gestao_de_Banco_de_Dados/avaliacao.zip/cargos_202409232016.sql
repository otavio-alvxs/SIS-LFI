INSERT INTO rh.cargos (id_cargo,nome_cargo) VALUES
	 ('ANALISTA','Analista de Sistemas'),
	 ('ASSISTENTE','Assistente Administrativo'),
	 ('DIRETOR','Diretor'),
	 ('ESTAGIARIO','Estagiário'),
	 ('GERENTE','Gerente de Projetos');
