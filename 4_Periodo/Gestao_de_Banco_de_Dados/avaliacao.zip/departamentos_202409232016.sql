INSERT INTO rh.departamentos (nome_departamento) VALUES
	 ('Tecnologia da Informação'),
	 ('Desenvolvimento'),
	 ('Administração'),
	 ('Marketing'),
	 ('Financeiro');
