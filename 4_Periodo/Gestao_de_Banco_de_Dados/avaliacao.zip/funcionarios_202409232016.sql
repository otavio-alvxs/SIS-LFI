INSERT INTO rh.funcionarios (nome,sobrenome,data_nascimento,salario,id_cargo,id_departamento,cargo,departamento) VALUES
	 ('João','Silva','1980-01-01',5000.00,NULL,NULL,'ANALISTA',1),
	 ('Maria','Santos','1985-05-15',8000.00,NULL,NULL,'GERENTE',2),
	 ('Pedro','Almeida','1990-12-25',1500.00,NULL,NULL,'ESTAGIARIO',1),
	 ('Ana','Oliveira','1995-08-10',2500.00,NULL,NULL,'ASSISTENTE',3),
	 ('Carlos','Souza','1978-03-20',12000.00,NULL,NULL,'DIRETOR',3),
	 ('João','Silva','1980-05-15',15000.00,'DIRETOR',4,NULL,NULL),
	 ('Maria','Oliveira','1990-08-20',3000.00,'ASSISTENTE',5,NULL,NULL);
