INSERT INTO rh.treinamentos (nome_treinamento,data_inicio,data_fim,carga_horaria,`local`,ministrante,id_funcionario) VALUES
	 ('Introdução ao SQL','2024-01-01','2024-01-05',20,'Sala de treinamento','João Silva',1),
	 ('Gestão de Projetos','2024-03-15','2024-03-20',30,'Auditório','Maria Santos',2),
	 ('Desenvolvimento Web','2024-05-10','2024-05-25',40,'Laboratório','Pedro Almeida',3),
	 ('Introdução ao SQL','2024-01-10','2024-01-15',20,'Sala de treinamento','Carlos Silva',1),
	 ('Gestão de Projetos','2024-02-01','2024-02-05',16,'Laboratório','Ana Costa',2),
	 ('Excel Avançado','2024-03-01','2024-03-03',12,'Auditório','Roberto Lima',3);
